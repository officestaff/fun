package com.cg.bookingapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.bookingapp.dto.BookingDetails;
import com.cg.bookingapp.exception.VehicleException;
import com.cg.bookingapp.util.DBUtil;

public class BookingDaoImpl implements IBookingDao {

	@Override
	public int addBookingDetails(BookingDetails bookingDetails) throws VehicleException {
		Connection con=DBUtil.getConnection();
		int ret;
		if(con==null) {
			throw new VehicleException("Unable to obtain connection");
		}
		try {
			PreparedStatement stat=
					con.prepareStatement(QueryMapper.INSERT_QUERY);
			stat.setString(1, bookingDetails.getCustomerName());
			stat.setString(2, bookingDetails.getAddress());
			stat.setString(3, bookingDetails.getPincode());
			stat.setString(4, bookingDetails.getStatus());
			stat.setString(5, bookingDetails.getVehicleNo());
			ret=stat.executeUpdate();
			if(ret==0) {
				throw new VehicleException("Insert Operation failed");
			}
			else {
				Statement stat1=con.createStatement();
				ResultSet rs=stat1.executeQuery(QueryMapper.GET_BOOKINGID);
				rs.next();
				ret=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			throw new VehicleException(e.getMessage());
		}
		
		
		return ret;
	}

	@Override
	public List<BookingDetails> viewAllBookings() throws VehicleException {
		Connection con=DBUtil.getConnection();
		List<BookingDetails> bookings=new ArrayList<BookingDetails>();
		if(con==null) {
			throw new VehicleException("Unable to obtain connection");
			
		}
		try {
			Statement stat=con.createStatement();
			ResultSet rs=stat.executeQuery(QueryMapper.SELECT_ALL_QUERY);
			while(rs.next()) {
				BookingDetails bookingDetails=new BookingDetails();
				bookingDetails.setBookingId(rs.getInt(1));
				bookingDetails.setCustomerName(rs.getString(2));
				bookingDetails.setAddress(rs.getString(3));
				bookingDetails.setPincode(rs.getString(4));
				bookingDetails.setStatus(rs.getString(5));
				bookingDetails.setVehicleNo(rs.getString(6));
				bookingDetails.setBookingDate(rs.getDate(7).toLocalDate());
				bookings.add(bookingDetails);
			}
			
		} catch (SQLException e) {
			throw new VehicleException(e.getMessage());
		}
		
		return bookings;
	}

	@Override
	public BookingDetails viewBookingById(int bookingId) throws VehicleException {
		Connection con=DBUtil.getConnection();
		BookingDetails bookingDetails=null;
		if(con==null) {
			throw new VehicleException("Unable to obtain connection");
			
		}
		try {
			PreparedStatement stat=
					con.prepareStatement(QueryMapper.SELECT_BY_ID);
			stat.setInt(1, bookingId);
			ResultSet rs=stat.executeQuery();
			if(rs.next()) {
				bookingDetails=new BookingDetails();
				bookingDetails.setBookingId(rs.getInt(1));
				bookingDetails.setCustomerName(rs.getString(2));
				bookingDetails.setBookingDate(rs.getDate(3).toLocalDate());
				bookingDetails.setVehicleNo(rs.getString(4));
				bookingDetails.setStatus(rs.getString(5));
				
			}
			else {
				throw new VehicleException("Booking with id "+bookingId+" does not exist");
			}
		} catch (SQLException e) {
			throw new VehicleException(e.getMessage());
		}
		
		
		return bookingDetails;
	}

}
