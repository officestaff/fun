package com.cg.bookingapp.dao;

public interface QueryMapper {
	String INSERT_QUERY="INSERT INTO bookingDetails VALUES(bookingseq.nextval,?,?,?,?,?,sysdate)";
	String GET_BOOKINGID="SELECT bookingseq.currval FROM dual";
	String SELECT_ALL_QUERY="SELECT * FROM bookingDetails";
	String SELECT_BY_ID="SELECT bookingId,customerName,bookingDate,vehicleNo,status from bookingDetails where bookingId=?";
}
