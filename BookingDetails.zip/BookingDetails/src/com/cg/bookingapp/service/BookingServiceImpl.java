package com.cg.bookingapp.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import com.cg.bookingapp.dao.BookingDaoImpl;
import com.cg.bookingapp.dao.IBookingDao;
import com.cg.bookingapp.dto.BookingDetails;
import com.cg.bookingapp.exception.VehicleException;

public class BookingServiceImpl implements BookingService {
	IBookingDao bookingDao;
	
	Properties props=null;
	public  BookingServiceImpl() throws VehicleException {
		props=new Properties();
		bookingDao=new BookingDaoImpl();
		try {
			FileInputStream fis=new FileInputStream("data.properties");
			props.load(fis);
			
		} catch (FileNotFoundException e) {
			
		} catch (IOException e) {
			throw new VehicleException(e.getMessage());
		}
	}
	
	@Override
	public BookingDetails validateBooking(BookingDetails bookingDetails) throws VehicleException {
		if(!bookingDetails.getCustomerName().matches("[A-Z][A-Za-z]{1,19}")) {
			throw new VehicleException("Customer Name should start with a capital letter and can have a maximum of 20 characters");
			
		}
		if(bookingDetails.getPincode().matches("\\d{6}")) {
			if(props.containsKey(bookingDetails.getPincode())) {
				bookingDetails.setVehicleNo(props.getProperty(bookingDetails.getPincode()));
				bookingDetails.setStatus("Accepted");
			}
			else {
				throw new VehicleException("Service is not available in that locality");
			}
		}
		else {
			throw new VehicleException("Pincode should be 6 digits");
		}
		return bookingDetails;
	}

	@Override
	public int addBookingDetails(BookingDetails bookingDetails) throws VehicleException {
		// TODO Auto-generated method stub
		return bookingDao.addBookingDetails(bookingDetails);
	}

	@Override
	public List<BookingDetails> viewAllBookings() throws VehicleException {
		// TODO Auto-generated method stub
		return bookingDao.viewAllBookings();
	}

	@Override
	public BookingDetails viewBookingById(int bookingId) throws VehicleException {
		// TODO Auto-generated method stub
		return bookingDao.viewBookingById(bookingId)
				;
	}

}
