package com.cg.bookingapp.service;

import java.util.List;

import com.cg.bookingapp.dto.BookingDetails;
import com.cg.bookingapp.exception.VehicleException;

public interface BookingService {
	BookingDetails validateBooking(BookingDetails bookingDetails) throws VehicleException;
	int addBookingDetails(BookingDetails bookingDetails) throws VehicleException;
	List<BookingDetails> viewAllBookings() throws VehicleException;
	BookingDetails viewBookingById(int bookingId) throws VehicleException;
}
