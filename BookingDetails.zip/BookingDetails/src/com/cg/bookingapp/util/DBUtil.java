package com.cg.bookingapp.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.bookingapp.exception.VehicleException;

public class DBUtil {
	
	public static Connection getConnection() throws VehicleException {
		try {
			FileInputStream fis=
					new FileInputStream("db.properties");
			Properties props=
					new Properties();
			props.load(fis);
			String url=props.getProperty("oracle.url");
			String username=props.getProperty("oracle.username");
			String password=props.getProperty("oracle.password");
			Class.forName(props.getProperty("oracle.driver"));
			Connection con=DriverManager.getConnection(url,username,password);
			return con;
			
		} catch (FileNotFoundException e) {
			throw new VehicleException(e.getMessage());
		} catch (IOException e) {
			throw new VehicleException(e.getMessage());
		} catch (ClassNotFoundException e) {
			throw new VehicleException(e.getMessage());
		} catch (SQLException e) {
			throw new VehicleException(e.getMessage());
		}
		
	}
	
}
