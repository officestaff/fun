package com.cg.bookingapp.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.bookingapp.dto.BookingDetails;
import com.cg.bookingapp.exception.VehicleException;
import com.cg.bookingapp.service.BookingService;
import com.cg.bookingapp.service.BookingServiceImpl;

public class BookingClient {
	BookingService bookingService;
	public BookingClient() {
		try {
			bookingService=new BookingServiceImpl();
		} catch (VehicleException e) {
			System.err.println("An Error Occured" + e.getMessage());
		}
	}
	static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
		BookingClient client=new BookingClient();
		String response;
		while(true) {
			System.out.println("1. Reserve a Bus");
			System.out.println("2. View Booking Details");
			System.out.println("3. View Booking by Id");
			System.out.println("4. Exit");
			System.out.println("Enter your Choice");
			response=scan.nextLine();
			switch (response) {
			case "1":
				client.addBookingDetails();
				break;
			case "2":
				client.viewBookings();
				break;
			case "3":
				client.viewBookingById();
				break;
			case "4":
				System.exit(0);

			default:
				System.out.println("Invalid Option");
				break;
			}
		}

	}
	public void addBookingDetails() {
		scan.useDelimiter("\n");
		BookingDetails bookingDetails=new BookingDetails();
		System.out.println("Enter Customer Name");
		bookingDetails.setCustomerName(scan.nextLine());
		System.out.println("Enter Address");
		bookingDetails.setAddress(scan.nextLine());
		System.out.println("Enter Pincode");
		bookingDetails.setPincode(scan.nextLine());
		try {
			bookingDetails=bookingService.validateBooking(bookingDetails);
			/*System.out.println(bookingDetails.getCustomerName());
			System.out.println(bookingDetails.getAddress());
			System.out.println(bookingDetails.getPincode());
			System.out.println(bookingDetails.getStatus());
			System.out.println(bookingDetails.getVehicleNo());*/
			int ret=bookingService.addBookingDetails(bookingDetails);
			System.out.println("Booking Details with Id "+ret+" Confirmed");
		} catch (VehicleException e) {
			System.err.println("An Error Occured" + e.getMessage());
		}
		
		
		
	}
	public void viewBookings() {
		try {
			List<BookingDetails> bookings=
					bookingService.viewAllBookings();
			System.out.println("\tBooking Id\tName\tPincode\tBooking date\tVehicleNo");
			for (BookingDetails bd : bookings) {
				System.out.println("\t"+bd.getBookingId()+"\t\t"+bd.getCustomerName()+"\t"+bd.getPincode()+"\t"+bd.getBookingDate()+"\t"+bd.getVehicleNo());;
			}
		} catch (VehicleException e) {
			// TODO Auto-generated catch block
			System.out.println("An Error occured "+e.getMessage());
		}
		
	}
	public void viewBookingById() {
		System.out.println("Enter Booking Id");
		String bookingId=scan.nextLine();
		if(bookingId.matches("\\d{4}")) {
			try {
				BookingDetails bookingDetails=bookingService.viewBookingById(Integer.parseInt(bookingId));
				System.out.println("Booking Id : "+bookingDetails.getBookingId());
				System.out.println("Customer Name : "+bookingDetails.getCustomerName());
				System.out.println("Booking Date : "+bookingDetails.getBookingDate());
				System.out.println("Vehicle Number : "+bookingDetails.getVehicleNo());
				System.out.println("Status : "+bookingDetails.getStatus());
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				try {
					throw new VehicleException(e.getMessage());
				} catch (VehicleException e1) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
			} catch (VehicleException e) {
				System.err.println(e.getMessage());
			}
		}
	}

}
