package com.cg.bookingapp.exception;

public class VehicleException extends Exception {
	public VehicleException() {
		super();
	}
	public VehicleException(String message) {
		super(message);
	}
}
