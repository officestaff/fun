package com.capgemini.hbms.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserService;

@Controller
public class HBMSController {

	@Autowired
	private IUserService userService;

	@Autowired
	private IHotelService hotelService;

	@Autowired
	private IRoomService roomService;

	@Autowired
	private IBookingService bookingService;

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public IHotelService getHotelService() {
		return hotelService;
	}

	public void setHotelService(IHotelService hotelService) {
		this.hotelService = hotelService;
	}

	public IRoomService getRoomService() {
		return roomService;
	}

	public void setRoomService(IRoomService roomService) {
		this.roomService = roomService;
	}

	public IBookingService getBookingService() {
		return bookingService;
	}

	public void setBookingService(IBookingService bookingService) {
		this.bookingService = bookingService;
	}

	@RequestMapping("showHomePage")
	public String homePage() {
		return "login";
	}

	@RequestMapping("loginPage")
	public ModelAndView loginPage() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("loginCheck","");
		mv.addObject("registerSuccess","");
		mv.setViewName("login");
		return mv;
	}
	
	@RequestMapping("construction")
	public ModelAndView constructionPage() {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("construction");
		return mv;
	}

	@RequestMapping("/registerPage")
	public ModelAndView registerPage() {

		UserDetailsBean userDetails = new UserDetailsBean();
		ModelAndView mv = new ModelAndView();
		mv.addObject("userDetails", userDetails);
		mv.addObject("userNameCheck","");
		mv.setViewName("register");
		return mv ;
	}

	@RequestMapping(value = "check", method = RequestMethod.POST)
	public ModelAndView check(@RequestParam("submit") String action,
			@ModelAttribute("userBean") UserDetailsBean userDetailsBean,
			BindingResult result) {

		ModelAndView mv = new ModelAndView();

		if (action.equals("Register")) {
			mv.setViewName("register");
		} else if (action.equals("Login")) {
			if (result.hasErrors()) {
				mv.setViewName("error");
				mv.addObject("errMsg", result);
			} else {
				try {

					boolean isValidUser = userService
							.isValidCredentials(userDetailsBean);
					
					if (isValidUser
							&& (userDetailsBean.getRole().equals("Customer") || userDetailsBean
									.getRole().equals("Employee"))) {

						UserDetailsBean userDetail = userService
								.isValidUser(userDetailsBean);
						mv.setViewName("userfunctions");
						mv.addObject("userId", userDetail.getUserId());

					} else if (isValidUser
							&& userDetailsBean.getRole().equals("Admin")) {
						mv.setViewName("loginsuccess");
					} else {
						mv.setViewName("login");
						mv.addObject("loginCheck",
								"Username or Password does not exist !!");
						mv.addObject("");
						
					}

				} catch (HBMSException e) {
					mv.setViewName("error");
					mv.addObject("errMsg", e.getMessage());
				}
			}
		}

		return mv;
	}

	@RequestMapping("/register")
	public ModelAndView register(
			@ModelAttribute("userDetails") @Valid UserDetailsBean userDetails,
			BindingResult result) {

		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv = new ModelAndView("register", "userDetails", userDetails);
		} else {

			int userId = 0;
			try {
				System.out.println(userDetails.getUserName());
				boolean isValidUserName = userService
						.isValidUserName(userDetails);
				if (!isValidUserName) {
					userId = userService.RegisterUser(userDetails);
					if (userId == 0) {
						mv.addObject("errMsg", "Data could not be inserted");
						mv.setViewName("error");
					} else {
						mv.addObject("registerSuccess","Successfully registered !!<br>Login Here");
						mv.addObject("loginCheck","");
						mv.setViewName("login");
					}
				}else{
					mv.addObject("userDetails", userDetails);
					mv.addObject("userNameCheck","User Name already exists !!");
					mv.setViewName("register");
				}
			} catch (HBMSException e) {
				mv.addObject("errMsg",
						"Data could not be inserted<br><br>" + e.getMessage());
				mv.setViewName("error");
			}
		}
		return mv;
	}

	@RequestMapping(value = "searchAndBookHotel", method = RequestMethod.POST)
	public ModelAndView viewCities(@RequestParam("userId") int userId) {

		ModelAndView mv = new ModelAndView();
		List<String> cities = new ArrayList<String>();
		try {
			cities = hotelService.viewCities();
			if (cities.isEmpty()) {
				mv.addObject("errMsg", "No cities found<br><br>");
				mv.setViewName("error");
			} else {
				mv.addObject("cities", cities);
				mv.addObject("userId", userId);
				mv.setViewName("viewcities");
			}
		} catch (HBMSException e) {
			mv.addObject("errMsg",
					"Cities could not be retrieved<br><br>" + e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping(value = "viewStatus", method = RequestMethod.POST)
	public ModelAndView viewStatus(@RequestParam("userId") String userId) {

		ModelAndView mv = new ModelAndView();
		List<BookingDetailsBean> bookingList = new ArrayList<BookingDetailsBean>();
		try {
			bookingList = bookingService.getBookingDetails(userId);
			if (bookingList.isEmpty()) {
				mv.addObject("errMsg", "No Booking list found for user "
						+ userId + "<br><br>");
				mv.setViewName("error");
			} else {
				mv.addObject("bookingList", bookingList);
				mv.setViewName("viewbookinglist");
			}
		} catch (HBMSException e) {
			mv.addObject(
					"errMsg",
					"Booking List could not be retrieved<br><br>"
							+ e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping(value = "searchHotel", method = RequestMethod.POST)
	public ModelAndView searchHotel(@RequestParam("city") String city,
			@RequestParam("userId") int userId) {

		ModelAndView mv = new ModelAndView();

		List<HotelDetailsBean> hotelsList = new ArrayList<HotelDetailsBean>();
		try {
			hotelsList = hotelService.viewHotels(city);
			if (hotelsList.isEmpty()) {
				mv.addObject("errMsg", "No hotels found in city " + city);
				mv.setViewName("error");
			} else {
				mv.addObject("hotels", hotelsList);
				mv.addObject("userId", userId);
				mv.setViewName("hotels");

			}
		} catch (HBMSException e) {
			mv.addObject("errMsg",
					"Hotels could not be retrieved<br><br>" + e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping("searchRoom")
	public ModelAndView searchRoom(@RequestParam("hotelId") String hotelId,
			@RequestParam("userId") int userId) {

		ModelAndView mv = new ModelAndView();

		List<RoomDetailsBean> roomsList = new ArrayList<RoomDetailsBean>();
		try {
			roomsList = roomService.viewRooms(hotelId);
			if (roomsList.isEmpty()) {
				mv.addObject("errMsg", "No rooms found in the hotel Id"
						+ hotelId);
				mv.setViewName("error");
			} else {
				mv.addObject("rooms", roomsList);
				mv.addObject("userId", userId);
				mv.setViewName("rooms");

			}
		} catch (HBMSException e) {
			mv.addObject("errMsg",
					"Rooms could not be retrieved<br><br>" + e.getMessage());
			mv.setViewName("error");
		}

		return mv;
	}

	@RequestMapping("bookRoom")
	public ModelAndView bookRoom(@RequestParam("roomId") String roomId,
			@RequestParam("hotelId") String hotelId,
			@RequestParam("userId") int userId) {

		ModelAndView mv = new ModelAndView();
		mv.addObject("roomId", roomId);
		mv.addObject("hotelId", hotelId);
		mv.addObject("userId", userId);
		mv.addObject("dateCheck", "");
		mv.setViewName("bookroom");

		System.out.println(userId);

		return mv;
	}

	@RequestMapping(value = "insertBookingDetails", method = RequestMethod.POST)
	public ModelAndView book(@RequestParam("bookFrom") String bookFrom,
			@RequestParam("bookTo") String bookTo,
			@RequestParam("roomId") String roomId,
			@RequestParam("userId") String userId,
			@RequestParam("noOfAdults") int noOfAdults,
			@RequestParam("noOfChildren") int noOfChildren) {
		ModelAndView mv = new ModelAndView();
		boolean isvalidDate = true;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		TemporalAccessor ta1 = dtf.parse(bookFrom);
		LocalDate bookedFrom = LocalDate.from(ta1);
		
		TemporalAccessor ta2 = dtf.parse(bookTo);
		LocalDate bookedTo = LocalDate.from(ta2);
		
		if(bookedFrom.isBefore(LocalDate.now())){
			isvalidDate = false;
		}else{
			if(bookedTo.isBefore(LocalDate.now())){
				isvalidDate = false;
			}else{
				if(bookedTo.isBefore(bookedFrom) || bookedTo.equals(bookedFrom)){
					isvalidDate = false;
				}
			}
		}
		

		
		
		BookingDetailsBean bookingDetail = new BookingDetailsBean();

		bookingDetail.setRoomId(roomId);
		bookingDetail.setUserId(userId);
		Date F = null;
		Date T = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			F = formatter.parse(bookFrom);
			T = formatter.parse(bookTo);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		bookingDetail.setBookedFrom(F);
		bookingDetail.setBookedTo(T);

		/*
		 * bookingDetail.setBookedTo(java.util.Date.from(bookedTo.atStartOfDay()
		 * .atZone(ZoneId.systemDefault()) .toInstant()));
		 */

		bookingDetail.setNoOfAdults(noOfAdults);
		bookingDetail.setNoOfChildren(noOfChildren);

		long daysBetween = ChronoUnit.DAYS.between(bookedFrom, bookedTo);

		double ratePerNight = 0;
		try {
			ratePerNight = roomService.getRoomRate(roomId);
		} catch (HBMSException e) {
			mv.addObject("errMsg",
					"Could not fetch room price<br><br>" + e.getMessage());
			mv.setViewName("error");
		}

		double amount = daysBetween * ratePerNight;

		bookingDetail.setAmount(amount);
		
		
		int bookingId = 0;
		
		if(isvalidDate){
			
		try {
			bookingId = bookingService.bookHotelRoom(bookingDetail);
			
			List<BookingDetailsBean> bookingDetailsList = bookingService.getBookingDetail(bookingId);
			mv.addObject("bookingDetails", bookingDetailsList);
			mv.setViewName("bookingdetails");
		} catch (HBMSException e) {
			mv.addObject("errMsg",
					"Room could not be booked<br><br>" + e.getMessage());
			mv.setViewName("error");
		}
		}else{
			mv.addObject("roomId", roomId);
			mv.addObject("hotelId", "");
			mv.addObject("userId", userId);
			mv.addObject("dateCheck", "'From' and 'To' Date should be greater than current date and 'To' Date should be greater than 'From' Date");
			mv.setViewName("bookroom");
		}
		return mv;
	}

/*	@RequestMapping("forgotPassword")
	public ModelAndView forgotPassword() {

		ModelAndView mv = new ModelAndView();

		mv.setViewName("forgotpassword");

		return mv;
	}
*/
}
