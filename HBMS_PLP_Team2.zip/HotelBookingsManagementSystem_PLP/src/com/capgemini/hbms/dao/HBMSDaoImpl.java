package com.capgemini.hbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

@Repository
@Transactional
public class HBMSDaoImpl implements IHBMSDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	/*============================USERS===================================*/
	
	@Override
	public int RegisterUser(UserDetailsBean userDetails)
			throws HBMSException {
		
		int userId = 0;

		/*Logger logger = Logger.getRootLogger();*/
		
		try{
			entityManager.persist(userDetails);
			entityManager.flush();

			userId = userDetails.getUserId();

			/*logger.info("UserDetailsDAO : User registered !!");*/
			
		} catch(Exception e){
			/*logger.info("UserDetailsDAO : User cannot be registered\n" + e.getMessage());*/
			throw new HBMSException("DAO register Error"); //Throws error	
		}
		
		
	return userId;
		
	}

	@Override
	public List<UserDetailsBean> usersDetail() throws HBMSException {

		List<UserDetailsBean> usersList = new ArrayList<UserDetailsBean>();
		
		try{
			TypedQuery<UserDetailsBean> qry = entityManager.createQuery("from UserDetailsBean",UserDetailsBean.class);
			
			usersList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
		return usersList;
	}

	@Override
	public UserDetailsBean getUserDetail(int userId) throws HBMSException {

		System.out.println(userId);
		UserDetailsBean userDetailsBean = new UserDetailsBean();
		
		try{
			/*TypedQuery<UserDetailsBean> qry = entityManager.createQuery("select * from UserDetailsBean where userName = :name",UserDetailsBean.class);
			qry.setParameter("name", userName);
			
			userDetailsBean = qry.getSingleResult();*/
			
			userDetailsBean = entityManager.find(UserDetailsBean.class,userId);
			
		} catch(Exception e){

			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
		return userDetailsBean;
	}
	
	/*============================HOTEL===================================*/
	
	
	@Override
	public List<HotelDetailsBean> viewHotels() throws HBMSException {


		List<HotelDetailsBean> hotelsList = new ArrayList<HotelDetailsBean>();
		
		try{
			TypedQuery<HotelDetailsBean> qry = entityManager.createQuery("from HotelDetailsBean",HotelDetailsBean.class);
			
			hotelsList = qry.getResultList();
			
		} catch(Exception e){

			throw new HBMSException("Dao Hotel view error"); //Throws error	
		}
		
		return hotelsList;
	}

	@Override
	public HotelDetailsBean viewHotel(String hotelId) throws HBMSException {

		HotelDetailsBean hotelDetailsBean = null;
		
		try{
			hotelDetailsBean = entityManager.find(HotelDetailsBean.class,hotelId);
			
		} catch(Exception e){

			throw new HBMSException(e.getMessage()); //Throws error	
		}
		
		return hotelDetailsBean;
	}

	/*============================ROOM DETAILS===================================*/

	@Override
	public List<String> getAllRoomIds() throws HBMSException {
		
		List<String> roomIdList = new ArrayList<String>();

		try {
			TypedQuery<String> qry = entityManager.createQuery("select roomId from RoomDetailsBean",
					String.class);

			roomIdList = qry.getResultList();

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomIdList;
	}

	@Override
	public double getRoomRate(String roomId) throws HBMSException {

		RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
		double roomRate = 0;
		try {
			roomDetailsBean = entityManager.find(RoomDetailsBean.class, roomId);
			roomRate = roomDetailsBean.getPerNightRate();
		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomRate;
	}

	@Override
	public List<RoomDetailsBean> getRoomHotelID() throws HBMSException {

		List<RoomDetailsBean> roomHotelIDList = new ArrayList<RoomDetailsBean>();

		try {
			TypedQuery<RoomDetailsBean> qry = entityManager.createQuery("select hotelId,roomId from RoomDetailsBean",
					RoomDetailsBean.class);

			roomHotelIDList = qry.getResultList();

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomHotelIDList;
	}

	@Override
	public RoomDetailsBean getRoomDetail(String roomId) throws HBMSException {

		RoomDetailsBean roomDetailsBean = new RoomDetailsBean();
		try {
			roomDetailsBean = entityManager.find(RoomDetailsBean.class, roomId);

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		return roomDetailsBean;
	}

	@Override
	public List<RoomDetailsBean> viewRooms(String hotelId) throws HBMSException {

		List<RoomDetailsBean> listOfRooms = new ArrayList<RoomDetailsBean>();

		try {
			TypedQuery<RoomDetailsBean> qry = entityManager.createQuery("from RoomDetailsBean where hotelId = :id",
					RoomDetailsBean.class);
			qry.setParameter("id", hotelId);

			listOfRooms = qry.getResultList();
		} catch (Exception e) {
			throw new HBMSException("Dao view room error"); // Throws error
		}
		return listOfRooms;
	}
	
	/*============================BOOKING DETAILS===================================*/

	@Override
	public int bookHotelRoom(BookingDetailsBean bookingDetailsBean)
			throws HBMSException {

		int bookingId = 0;
		try{
			entityManager.persist(bookingDetailsBean);
			
			bookingId = bookingDetailsBean.getBookingId();
			
		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}

		return bookingId;

	}

	@Override
	public List<BookingDetailsBean> getBookingDetail(int bookingId)
			throws HBMSException {
		
		List<BookingDetailsBean> bookingList = new ArrayList<BookingDetailsBean>();
		try{
			TypedQuery<BookingDetailsBean> qry = entityManager.createQuery("from BookingDetailsBean where bookingId = :id",BookingDetailsBean.class);
			qry.setParameter("id",bookingId);
			
			bookingList = qry.getResultList();

		} catch (Exception e) {
			throw new HBMSException(e.getMessage()); // Throws error
		}
		for(BookingDetailsBean detail : bookingList){
			System.out.println("Dao getBookingDetail error");
		}
		return bookingList;
	}

	@Override
	public List<BookingDetailsBean> getBookingDetails(String userId)
			throws HBMSException {

		List<BookingDetailsBean> bookingList = new ArrayList<BookingDetailsBean>();
		try{
			TypedQuery<BookingDetailsBean> qry = entityManager.createQuery("from BookingDetailsBean where userId=:id",BookingDetailsBean.class);
			qry.setParameter("id",userId);
			
			bookingList = qry.getResultList();
			
		} catch (Exception e) {
			
			throw new HBMSException(e.getMessage()); // Throws error
		}
		for(BookingDetailsBean detail : bookingList){
			System.out.println("List" + detail);
		}
		return bookingList;
	}

}
