package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHotelService {

	List<HotelDetailsBean> viewHotels(String city) throws HBMSException;

	HotelDetailsBean viewHotel(String hotelId) throws HBMSException;	
	
	List<HotelDetailsBean> viewHotelsList() throws HBMSException;
	
	List<String> viewCities() throws HBMSException;
}
