package com.capgemini.hbms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.dao.IHBMSDao;
import com.capgemini.hbms.exception.HBMSException;

@Service
public class HotelServiceImpl implements IHotelService {

	@Autowired
	private IHBMSDao hotelDetailsDao;

	@Override
	public List<HotelDetailsBean> viewHotels(String city) throws HBMSException {

		List<HotelDetailsBean> listOfHotels = hotelDetailsDao.viewHotels();
		List<HotelDetailsBean> hotelsBasedOnCity = new ArrayList<HotelDetailsBean>();

		for (HotelDetailsBean hotel : listOfHotels) {
			if (hotel.getCity().equalsIgnoreCase(city)) {
				hotelsBasedOnCity.add(hotel);
			}
		}
		return hotelsBasedOnCity;
	}

	@Override
	public HotelDetailsBean viewHotel(String hotelId) throws HBMSException {

		return hotelDetailsDao.viewHotel(hotelId);
	}

	@Override
	public List<HotelDetailsBean> viewHotelsList() throws HBMSException {

		return hotelDetailsDao.viewHotels();
	}

	public List<String> viewCities() throws HBMSException {

		List<HotelDetailsBean> listOfHotels;
		List<String> repeatedCities = new ArrayList<String>();
		List<String> cities = new ArrayList<String>();
		int flag = 1;
		listOfHotels = viewHotelsList();

		for (HotelDetailsBean hotel : listOfHotels) {
			repeatedCities.add(hotel.getCity());
		}

		for (String city : repeatedCities) {

			if (cities.isEmpty()) {
				cities.add(city);
			} else {

				for (String cityCheck : cities) {

					if (city.matches(cityCheck)) {
						flag = 0;
					}
				}
				if (flag == 1) {
					cities.add(city);
				}
				flag = 1;
			}
		}

		return cities;
	}

}
