package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IUserService {

	int RegisterUser(UserDetailsBean userDetails) throws HBMSException;
	
	UserDetailsBean isValidUser(UserDetailsBean userDetails) throws HBMSException;

	UserDetailsBean getUserDetail(int userId) throws HBMSException;
	
	boolean isValidUserName(UserDetailsBean userDetails) throws HBMSException;
	
	boolean isValidCredentials(UserDetailsBean userDetails) throws HBMSException;
}
